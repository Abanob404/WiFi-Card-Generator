export type Theme = 'modern' | 'elegant' | 'nature' | 'sunset' | 'minimal';
export type SecurityType = 'WPA' | 'WEP' | 'nopass';
export type CardSize = 'small' | 'medium' | 'large';
export type Language = 'en' | 'ar';

export interface WiFiData {
  ssid: string;
  password: string;
  securityType: SecurityType;
  theme: Theme;
  cardSize: CardSize;
  language: Language;
  customColor?: string;
  logo?: string;
}