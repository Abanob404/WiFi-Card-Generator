import React from 'react';
import QRCode from 'qrcode.react';
import { WiFiData } from '../types';
import { Wifi } from 'lucide-react';

interface WiFiCardProps {
  data: WiFiData;
  className?: string;
  hidePassword?: boolean;
}

export const WiFiCard: React.FC<WiFiCardProps> = ({ data, className = '', hidePassword = false }) => {
  const getQRValue = () => {
    const { ssid, password, securityType } = data;
    if (hidePassword) {
      return `WIFI:T:${securityType};S:${ssid};;`;
    }
    return `WIFI:T:${securityType};S:${ssid};P:${password};;`;
  };

  return (
    <div
      className={`theme-${data.theme} p-8 rounded-xl shadow-lg print-card ${className} ${
        data.cardSize === 'small' ? 'w-64' :
        data.cardSize === 'medium' ? 'w-80' : 'w-96'
      }`}
      style={{ direction: data.language === 'ar' ? 'rtl' : 'ltr' }}
    >
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-white/10 rounded-lg">
          <Wifi className="w-6 h-6" />
        </div>
        <h2 className="text-2xl font-bold">
          {data.language === 'ar' ? 'بيانات الواي فاي' : 'WiFi Details'}
        </h2>
      </div>

      <div className="flex flex-col items-center gap-6">
        <div className="bg-white p-4 rounded-xl shadow-sm">
          <QRCode
            value={getQRValue()}
            size={200}
            level="H"
            includeMargin={false}
            className="w-full h-full"
          />
        </div>

        <div className="text-center space-y-2">
          <p className="text-xl font-semibold">{data.ssid}</p>
          {!hidePassword && (
            <p className="text-base opacity-90">
              {data.language === 'ar' ? 'كلمة المرور:' : 'Password:'} {data.password}
            </p>
          )}
        </div>

        <p className="text-sm opacity-75 font-light">
          {data.language === 'ar'
            ? 'امسح رمز QR للاتصال تلقائياً'
            : 'Scan QR code to connect automatically'}
        </p>
      </div>
    </div>
  );
};