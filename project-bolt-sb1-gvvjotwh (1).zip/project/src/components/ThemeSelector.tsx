import React from 'react';
import { Theme } from '../types';
import { Palette } from 'lucide-react';

interface ThemeSelectorProps {
  theme: Theme;
  onChange: (theme: Theme) => void;
}

const themes: { value: Theme; label: string; description: string }[] = [
  { 
    value: 'modern',
    label: 'Modern',
    description: 'Clean and contemporary design with vibrant gradients'
  },
  { 
    value: 'elegant',
    label: 'Elegant',
    description: 'Sophisticated dark theme with premium feel'
  },
  { 
    value: 'nature',
    label: 'Nature',
    description: 'Fresh and organic feel with natural tones'
  },
  { 
    value: 'sunset',
    label: 'Sunset',
    description: 'Warm and inviting with sunset-inspired colors'
  },
  { 
    value: 'minimal',
    label: 'Minimal',
    description: 'Simple and clean design focusing on content'
  },
];

export const ThemeSelector: React.FC<ThemeSelectorProps> = ({ theme, onChange }) => {
  return (
    <div className="space-y-4">
      <label className="flex items-center gap-2 text-sm font-medium">
        <Palette className="w-4 h-4" />
        Select Theme
      </label>
      <div className="grid grid-cols-2 gap-3">
        {themes.map((t) => (
          <button
            key={t.value}
            onClick={() => onChange(t.value)}
            className={`relative flex flex-col items-start p-4 rounded-xl transition-all duration-200 ${
              theme === t.value
                ? 'ring-2 ring-blue-500 bg-blue-50'
                : 'hover:bg-gray-50 border border-gray-200'
            }`}
          >
            <span className="font-semibold mb-1">{t.label}</span>
            <span className="text-xs text-gray-500">{t.description}</span>
            <div
              className={`absolute top-2 right-2 w-6 h-6 rounded-full theme-${t.value} shadow-sm`}
            />
          </button>
        ))}
      </div>
    </div>
  );
};