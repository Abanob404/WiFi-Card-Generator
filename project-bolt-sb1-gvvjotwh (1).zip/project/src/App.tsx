import React, { useState, useRef, useCallback } from 'react';
import { WiFiCard } from './components/WiFiCard';
import { ThemeSelector } from './components/ThemeSelector';
import { WiFiData, Theme, SecurityType, CardSize, Language } from './types';
import { Eye, EyeOff, Download, Printer, Globe2, Wifi, Lock } from 'lucide-react';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';

function App() {
  const [data, setData] = useState<WiFiData>({
    ssid: '',
    password: '',
    securityType: 'WPA',
    theme: 'modern',
    cardSize: 'medium',
    language: 'en',
  });

  const [showPassword, setShowPassword] = useState(false);
  const [showPasswordInQR, setShowPasswordInQR] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  const handlePrint = useCallback(() => {
    if (cardRef.current) {
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        printWindow.document.write(`
          <html>
            <head>
              <title>WiFi Card - ${data.ssid}</title>
              <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700&display=swap" rel="stylesheet">
              <style>
                @media print {
                  @page {
                    size: A4;
                    margin: 0;
                  }
                  body {
                    margin: 2cm;
                    -webkit-print-color-adjust: exact;
                    print-color-adjust: exact;
                  }
                }
                ${document.querySelector('style')?.innerHTML || ''}
              </style>
            </head>
            <body>
              ${cardRef.current.outerHTML}
            </body>
          </html>
        `);
        printWindow.document.close();
        printWindow.focus();
        setTimeout(() => {
          printWindow.print();
          printWindow.close();
        }, 250);
      }
    }
  }, [data.ssid]);

  const handleSavePDF = async () => {
    if (cardRef.current) {
      const canvas = await html2canvas(cardRef.current, {
        scale: 3, // Increase resolution (300 DPI)
        useCORS: true,
        allowTaint: true,
        backgroundColor: null,
        logging: false,
        windowWidth: cardRef.current.scrollWidth * 3,
        windowHeight: cardRef.current.scrollHeight * 3
      });

      const imgWidth = 210; // A4 width in mm
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      
      const pdf = new jsPDF({
        orientation: imgHeight > imgWidth ? 'portrait' : 'landscape',
        unit: 'mm',
        format: 'a4',
      });

      pdf.addImage(
        canvas.toDataURL('image/jpeg', 1.0),
        'JPEG',
        0,
        0,
        imgWidth,
        imgHeight,
        undefined,
        'FAST'
      );

      pdf.save(`wifi-card-${data.ssid}.pdf`);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <header className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">WiFi Card Generator</h1>
          <p className="text-gray-600">Create beautiful, printable WiFi cards with QR codes</p>
        </header>

        <div className="grid md:grid-cols-2 gap-8">
          <div className="bg-white p-6 rounded-xl shadow-lg">
            <div className="space-y-6">
              <div>
                <label className="flex items-center gap-2 text-sm font-medium mb-2">
                  <Wifi className="w-4 h-4" />
                  Network Name (SSID)
                </label>
                <input
                  type="text"
                  value={data.ssid}
                  onChange={(e) => setData({ ...data, ssid: e.target.value })}
                  className="w-full px-4 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Enter network name"
                />
              </div>

              <div>
                <label className="flex items-center gap-2 text-sm font-medium mb-2">
                  Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={data.password}
                    onChange={(e) => setData({ ...data, password: e.target.value })}
                    className="w-full px-4 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter password"
                  />
                  <button
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    {showPassword ? (
                      <EyeOff className="w-4 h-4" />
                    ) : (
                      <Eye className="w-4 h-4" />
                    )}
                  </button>
                </div>
              </div>

              <div>
                <label className="flex items-center gap-2 text-sm font-medium mb-2">
                  Security Type
                </label>
                <select
                  value={data.securityType}
                  onChange={(e) => setData({ ...data, securityType: e.target.value as SecurityType })}
                  className="w-full px-4 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="WPA">WPA/WPA2</option>
                  <option value="WEP">WEP</option>
                  <option value="nopass">No Password</option>
                </select>
              </div>

              <ThemeSelector
                theme={data.theme}
                onChange={(theme) => setData({ ...data, theme })}
              />

              <div>
                <label className="flex items-center gap-2 text-sm font-medium mb-2">
                  Card Size
                </label>
                <select
                  value={data.cardSize}
                  onChange={(e) => setData({ ...data, cardSize: e.target.value as CardSize })}
                  className="w-full px-4 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="small">Small</option>
                  <option value="medium">Medium</option>
                  <option value="large">Large</option>
                </select>
              </div>

              <div>
                <label className="flex items-center gap-2 text-sm font-medium mb-2">
                  <Globe2 className="w-4 h-4" />
                  Language
                </label>
                <select
                  value={data.language}
                  onChange={(e) => setData({ ...data, language: e.target.value as Language })}
                  className="w-full px-4 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="en">English</option>
                  <option value="ar">Arabic</option>
                </select>
              </div>

              <div className="flex items-center gap-2">
                <Lock className="w-4 h-4 text-gray-600" />
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={showPasswordInQR}
                    onChange={(e) => setShowPasswordInQR(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                  <span className="ms-3 text-sm font-medium text-gray-600">
                    {data.language === 'ar' ? 'إظهار كلمة المرور في رمز QR' : 'Show password in QR code'}
                  </span>
                </label>
              </div>

              <div className="flex gap-4">
                <button
                  onClick={handlePrint}
                  className="flex-1 flex items-center justify-center gap-2 bg-blue-500 text-white px-6 py-2 rounded-lg hover:bg-blue-600 transition-colors"
                >
                  <Printer className="w-4 h-4" />
                  Print
                </button>
                <button
                  onClick={handleSavePDF}
                  className="flex-1 flex items-center justify-center gap-2 bg-gray-800 text-white px-6 py-2 rounded-lg hover:bg-gray-900 transition-colors"
                >
                  <Download className="w-4 h-4" />
                  Save PDF
                </button>
              </div>
            </div>
          </div>

          <div className="flex items-start justify-center p-4 bg-white rounded-xl shadow-lg">
            <div ref={cardRef}>
              <WiFiCard data={data} hidePassword={!showPasswordInQR} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;